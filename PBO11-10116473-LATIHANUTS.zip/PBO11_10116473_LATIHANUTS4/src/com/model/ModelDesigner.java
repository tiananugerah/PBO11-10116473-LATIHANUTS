/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.model;

/**
 *
 * @author shorfana
 */
public class ModelDesigner extends ModelEmploye {

    int bonus = 50000;

    public void bonusDesigner() {
        System.out.println("Salary Employe Designer : " + salary);
        System.out.println("Bonus Designer : " + bonus);
    }
}
